#include <stdio.h>

int main()
{
    if (0.1 + 0.2 == 0.3)
        printf("True!\n");
    else
        printf("False!\n");

    printf("0.3 = %.17f\n", 0.1 + 0.2);

    return 0;
}