#include <stdio.h>

int main()
{
    char str[] = "hello";

    printf("%ld\n", sizeof(str));

    return 0;
}