#include <stdio.h>

int main()
{
    int x, y, z;

    scanf("%i %i %i", &x, &y, &z);

    printf("%d %d %d\n", x, y, z);

    return 0;
}